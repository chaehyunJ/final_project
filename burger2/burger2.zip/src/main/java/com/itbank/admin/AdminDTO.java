package com.itbank.admin;

public class AdminDTO {
	
	private String adminid, adminpw, adminname, storename, storeregion, admingrade;

	public String getAdminid() {
		return adminid;
	}

	public void setAdminid(String adminid) {
		this.adminid = adminid;
	}

	public String getAdminpw() {
		return adminpw;
	}

	public void setAdminpw(String adminpw) {
		this.adminpw = adminpw;
	}

	public String getAdminname() {
		return adminname;
	}

	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}

	public String getStorename() {
		return storename;
	}

	public void setStorename(String storename) {
		this.storename = storename;
	}

	public String getStoreregion() {
		return storeregion;
	}

	public void setStoreregion(String storeregion) {
		this.storeregion = storeregion;
	}

	public String getAdmingrade() {
		return admingrade;
	}

	public void setAdmingrade(String admingrade) {
		this.admingrade = admingrade;
	}
}
